package NewSim;
import java.util.ArrayList;

/**
 * @author William Booker
 * Based on work by Kevin and Mark
 * Speciation Simulation v.2.0 - 10/12/16
 * For use in Dr. Hougen's REAL Lab
 */
public class SeedList extends ArrayList<Seed> {
	private static final long serialVersionUID = 1L;
}

